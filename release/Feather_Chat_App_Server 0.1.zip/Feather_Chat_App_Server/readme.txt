Thanks for downloading version 0.1!

If your on windows run the .bat, but if your on on Mac or Linux you will need
to run the jar using the java console.